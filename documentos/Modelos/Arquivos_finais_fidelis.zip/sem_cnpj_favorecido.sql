insert into favorecidos (cnpj, atividadeprincipal) VALUES ('11111111111','SEM INFORMACAO');
insert into favorecidos (cnpj, atividadeprincipal) VALUES ('22222222222','SAQUE');
insert into favorecidos (cnpj, atividadeprincipal) VALUES ('33333333333','SIGILOSO');